const base_url = "http://localhost:7080";

export default base_url;